﻿# TODO: Translation updated at 2022-03-16 13:15

translate english strings:

    # game/options.rpy:15
    old "Earth-chan's Adventure"
    new ""

    # game/options.rpy:32
    old "Game written by Daniel & Bruno. Art by Natalie & Maryam."
    new ""

