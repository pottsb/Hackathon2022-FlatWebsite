﻿# TODO: Translation updated at 2022-03-16 13:15

# game/script.rpy:25
translate english start_5c370786:

    # t "Alright class!"
    t ""

# game/script.rpy:26
translate english start_c33928d3:

    # t "Today we have a brand new member of our class."
    t ""

# game/script.rpy:27
translate english start_134c772d:

    # t "She doesn't know anyone from around here, so please be kind to her."
    t ""

# game/script.rpy:28
translate english start_1bd315b8:

    # t "She has asked to introduce herself, so here she is:"
    t ""

# game/script.rpy:32
translate english start_5d67348b:

    # "???" "Hello everyone, im your new class member."
    "???" ""

# game/script.rpy:33
translate english start_e0793bf7:

    # e "Please, call me Earth-Chan."
    e ""

# game/script.rpy:36
translate english start_402e022a:

    # e "Im happy to meet you all today and hope we can all become great friends!"
    e ""

# game/script.rpy:37
translate english start_b9ab12f0:

    # e "My favourite subject is geography, as I love to learn about this planet and how we effect it."
    e ""

# game/script.rpy:40
translate english start_0af36474:

    # e "Thank you."
    e ""

# game/script.rpy:42
translate english start_354cca8e:

    # "" "*The class is buzzing with excitement*"
    "" ""

# game/script.rpy:44
translate english start_7899d689:

    # t "What a lovely introduction, im sure we will all get along great!"
    t ""

# game/script.rpy:45
translate english start_73f8fe08:

    # t "Would a few of you like to introduce yourselves as well?"
    t ""

# game/script.rpy:46
translate english start_4ffc8e0f:

    # "???" "I will!"
    "???" ""

# game/script.rpy:52
translate english start_3833fb78:

    # n "Its wonderful to meet you. Im Nuclear, but you can call me Nukey for short!"
    n ""

# game/script.rpy:53
translate english start_0edac812:

    # n "I love the world too, and hope to preserve it whilst helping the people that live in it. I want to become an engineer like my dad!."
    n ""

# game/script.rpy:54
translate english start_cfcc61dc:

    # n "Also, your hair is -like- really cute."
    n ""

# game/script.rpy:59
translate english start_2afdaa71:

    # n "Lets become great friends!"
    n ""

# game/script.rpy:63
translate english start_30804041:

    # "" "*Nukey sits back down.*"
    "" ""

# game/script.rpy:65
translate english start_e2afc447:

    # t "And who is next?"
    t ""

# game/script.rpy:66
translate english start_31217f72:

    # "???" "My turn! My turn! My turn!"
    "???" ""

# game/script.rpy:71
translate english start_591c7cd3:

    # s "My name is Sunny!"
    s ""

# game/script.rpy:73
translate english start_4adefb36:

    # s "My friends all say that I can be super hyper and friendly."
    s ""

# game/script.rpy:77
translate english start_e2ef7cb7:

    # s "but I often find myself under the weather, and that really puts me down a notch."
    s ""

# game/script.rpy:81
translate english start_3634f2df:

    # s "Anyhow, its really cool to meet you."
    s ""

# game/script.rpy:82
translate english start_0d9eaf44:

    # s "See ya!"
    s ""

# game/script.rpy:85
translate english start_d365711b:

    # t "Sunny, how many times must I tell you?"
    t ""

# game/script.rpy:86
translate english start_27104c74:

    # t "NO RUNNING IN THE CLASSRO- oh."
    t ""

# game/script.rpy:87
translate english start_6a4cba35:

    # t "They've already fallen asleep. Great."
    t ""

# game/script.rpy:88
translate english start_0feadfd5:

    # t "Would anyone else like to say hello to our new classmate?"
    t ""

# game/script.rpy:89
translate english start_dbd01cc7:

    # "" "The class is silent"
    "" ""

# game/script.rpy:90
translate english start_ff6a2c26:

    # t "Cole! You're awfully quiet today. Why dont you say hello?"
    t ""

# game/script.rpy:93
translate english start_7788d054:

    # c "Hi. Im Cole."
    c ""

# game/script.rpy:94
translate english start_d19f855d:

    # c "..."
    c ""

# game/script.rpy:95
translate english start_1029bb41:

    # c "I honestly think your loving the planet?"
    c ""

# game/script.rpy:96
translate english start_dbc50f56:

    # c "Is lame as hell."
    c ""

# game/script.rpy:99
translate english start_e15a803a:

    # e "Why would you say that? It's so mean!"
    e ""

# game/script.rpy:102
translate english start_8f560621:

    # t "Cole! How dare you be so rude to our newest friend. Detention!"
    t ""

# game/script.rpy:105
translate english start_7b17815e:

    # t "Don't worry about him. He is always like this to new people, and never behaves himself. If you run in to any problems, just tell me. Ok?"
    t ""

# game/script.rpy:108
translate english start_c06caedc:

    # e "Ok... Thank you!"
    e ""

# game/script.rpy:110
translate english start_78b19010:

    # t "Now, who do you want to sit down with?"
    t ""

# game/script.rpy:129
translate english sitwithnuclear_85fee629:

    # n "You want to sit with me? Thanks so much!"
    n ""

# game/script.rpy:131
translate english sitwithnuclear_3389f10e:

    # n "I think were gonna get along really well."
    n ""

# game/script.rpy:133
translate english sitwithnuclear_cd3ca3ac:

    # e "Yeah, im sure we can become best friends."
    e ""

# game/script.rpy:136
translate english sitwithnuclear_a35b1a62:

    # e "What is it you love about engineering so much?"
    e ""

# game/script.rpy:138
translate english sitwithnuclear_de2b181a:

    # n "My dad is a big inspiration, and works at a massive reactor thingy!"
    n ""

# game/script.rpy:139
translate english sitwithnuclear_a7ed9a69:

    # n "He says its the best compromise between clean energy and reliable output."
    n ""

# game/script.rpy:142
translate english sitwithnuclear_f5a1ad85:

    # n "In not too sure what that means, but it sure sounds important!"
    n ""

# game/script.rpy:143
translate english sitwithnuclear_57b1d21a:

    # t "OK CLASS! It's time for our first lesson. Geography!"
    t ""

# game/script.rpy:152
translate english sitwithsolar_3f59e0e6:

    # s "Holy cow! Your gonna sit with me? Dope!"
    s ""

# game/script.rpy:153
translate english sitwithsolar_a69625bb:

    # s "I know that together we can make this school year worth coming too"
    s ""

# game/script.rpy:155
translate english sitwithsolar_b65d2587:

    # s "SowhatdoyoudoinyoursparetimewhatsyournameagainhowoldareyouwhatschooldoyougotoholdonwegotothesameschoolwhydidIaskthatimjustsohappythatyoucametosayhellotomeandIhaveanewfriendbecausemostpeoplearekindofscaredbyhowmuchIcangetexcitedbylittlethingsandnewpeople"
    s ""

# game/script.rpy:157
translate english sitwithsolar_2be394d8:

    # s "*Falls asleep*"
    s ""

# game/script.rpy:160
translate english sitwithsolar_8ea21bfa:

    # e "*To self* That's going to happen a lot, isnt it?"
    e ""

# game/script.rpy:161
translate english sitwithsolar_57b1d21a:

    # t "OK CLASS! It's time for our first lesson. Geography!"
    t ""

# game/script.rpy:169
translate english sitwithcoal_37eb3c0c:

    # c "Seriously? Why did you even pick me?"
    c ""

# game/script.rpy:171
translate english sitwithcoal_3d87a18e:

    # c "I don't want to talk to you. Go away."
    c ""

# game/script.rpy:174
translate english sitwithcoal_44e95afe:

    # e "Im just curious as to why you hated what I had to say so much, im sure you're nice really!"
    e ""

# game/script.rpy:177
translate english sitwithcoal_ee75ab38:

    # c "Thanks, I guess."
    c ""

# game/script.rpy:179
translate english sitwithcoal_5d962013:

    # c "It's just..."
    c ""

# game/script.rpy:181
translate english sitwithcoal_f2e782ad:

    # c "Don't worry about it. I just dont like nature, thats all."
    c ""

# game/script.rpy:182
translate english sitwithcoal_7e014547:

    # c "As far as im concerned, all those plants can be burned to a cinder."
    c ""

# game/script.rpy:183
translate english sitwithcoal_f6333ea4:

    # e "Um... ok?"
    e ""

# game/script.rpy:184
translate english sitwithcoal_57b1d21a:

    # t "OK CLASS! It's time for our first lesson. Geography!"
    t ""

# game/script.rpy:190
translate english scene2_2ba2d7ae:

    # t "Today we will be looking at a big, important topic. That is, climate change."
    t ""

# game/script.rpy:191
translate english scene2_5c8765b6:

    # t "More specifically, we will be looking at how we create energy for our homes, and what that can do to the world around us."
    t ""

# game/script.rpy:192
translate english scene2_49aedaeb:

    # t "Ok class, who can name a way we make power?"
    t ""

# game/script.rpy:195
translate english scene2_22cda7af:

    # n "Nuclear reactors!"
    n ""

# game/script.rpy:196
translate english scene2_0793e412:

    # t "Thats correct! What could you tell us about those?"
    t ""

# game/script.rpy:197
translate english scene2_0ec0a8ee:

    # n "My dad works at one."
    n ""

# game/script.rpy:199
translate english scene2_ef5a3e8d:

    # n "um..."
    n ""

# game/script.rpy:201
translate english scene2_ad7379eb:

    # "" "The class stares blankly."
    "" ""

# game/script.rpy:202
translate english scene2_fd787415:

    # n "uh..."
    n ""

# game/script.rpy:204
translate english scene2_286808fa:

    # n "OH! I KNOW!"
    n ""

# game/script.rpy:206
translate english scene2_d12a5919:

    # n "They are meant to be for base power, as they always give about the same amount of energy."
    n ""

# game/script.rpy:207
translate english scene2_5a8e56ed:

    # n "It's super reliable!"
    n ""

# game/script.rpy:208
translate english scene2_36ffb75b:

    # n "That's all!"
    n ""

# game/script.rpy:210
translate english scene2_04368199:

    # "" "Nukey sits back down"
    "" ""

# game/script.rpy:211
translate english scene2_b2b2e73d:

    # t "Thats right! A nuclear reactor is used to provide a continuous, reliable source of energy to the country."
    t ""

# game/script.rpy:212
translate english scene2_8d148df2:

    # t "Its also pretty clean, with the waste products being only steam and spent fuel."
    t ""

# game/script.rpy:213
translate english scene2_f14652fd:

    # t "Rolls-Royce's small modular reactor is exactly what we mean - "
    t ""

# game/script.rpy:214
translate english scene2_570b3998:

    # t "It will sustain our power generation whilst being more cheap than ever before."
    t ""

# game/script.rpy:215
translate english scene2_03cbefc9:

    # t "Thank you for that contribution , Nukey."
    t ""

# game/script.rpy:216
translate english scene2_9ad9c5a2:

    # t "Does anyone else have any ideas?"
    t ""

# game/script.rpy:217
translate english scene2_f92cd1e5:

    # "" "..."
    "" ""

# game/script.rpy:218
translate english scene2_f92cd1e5_1:

    # "" "..."
    "" ""

# game/script.rpy:219
translate english scene2_f92cd1e5_2:

    # "" "..."
    "" ""

# game/script.rpy:221
translate english scene2_c2b4fb2c:

    # c "What about coal?"
    c ""

# game/script.rpy:222
translate english scene2_681e2731:

    # c "You know, fossils and whatnot..."
    c ""

# game/script.rpy:223
translate english scene2_c252d4b6:

    # c "Dinosaur juice!"
    c ""

# game/script.rpy:224
translate english scene2_ef5ff773:

    # t "Exactly right, Cole!"
    t ""

# game/script.rpy:225
translate english scene2_c12643e8:

    # t "Thank you for coming up and helping the class, its very good of you to help out"
    t ""

# game/script.rpy:227
translate english scene2_4dccff31:

    # c "Who even cares about the environment? It's just grass."
    c ""

# game/script.rpy:229
translate english scene2_26bf0a5f:

    # t "Those fossil fuels he mentioned are very cheap, but make the world a very dirty place"
    t ""

# game/script.rpy:234
translate english scene2_7156ac71:

    # "Earth-chan & Sunny" "A dirtier place??? Thats horrible!"
    "Earth-chan & Sunny" ""

# game/script.rpy:235
translate english scene2_78241238:

    # t "Please sit down."
    t ""

# game/script.rpy:236
translate english scene2_d0dfd06c:

    # "Earth-chan & Sunny" "Sorry Miss Teacher..."
    "Earth-chan & Sunny" ""

# game/script.rpy:239
translate english scene2_060e42c7:

    # t "Anyway, as I was saying"
    t ""

# game/script.rpy:240
translate english scene2_ac711951:

    # t "There are many disadvantages to using fossil fuels, such as it harming the environment and warming us up."
    t ""

# game/script.rpy:241
translate english scene2_b4210e65:

    # t "And yet we still use it every day."
    t ""

# game/script.rpy:242
translate english scene2_ce1f0a4e:

    # t "Its a funny old world, isnt it?"
    t ""

# game/script.rpy:243
translate english scene2_1827622c:

    # t "Ok, who else knows how we make our energy?"
    t ""

# game/script.rpy:246
translate english scene2_74c4da2c:

    # s "I know one!"
    s ""

# game/script.rpy:247
translate english scene2_2cc744b8:

    # s "Solar panels! They are totally clean"
    s ""

# game/script.rpy:249
translate english scene2_3eb7e7de:

    # s "It absorbs power from the sun and lets us use it."
    s ""

# game/script.rpy:250
translate english scene2_1ada8386:

    # s "How generous!"
    s ""

# game/script.rpy:252
translate english scene2_8ff18850:

    # s "But when it gets cloudy, I don't think it works so well"
    s ""

# game/script.rpy:253
translate english scene2_f27e2729:

    # s "So im not sure if they are good at all."
    s ""

# game/script.rpy:254
translate english scene2_bb1e0b77:

    # s "Sorry."
    s ""

# game/script.rpy:256
translate english scene2_abc147a4:

    # t "No need to feel down about it, Sunny."
    t ""

# game/script.rpy:257
translate english scene2_d3e77901:

    # t "Solar panels are a great, clean way to provide energy but it simply isn't reliable"
    t ""

# game/script.rpy:258
translate english scene2_a86120ce:

    # t "How many cloudy days would it take for us to run out of power if we relied soley upon it?"
    t ""

# game/script.rpy:259
translate english scene2_c546172f:

    # t "They are worth using for now, but we could do with a more permenant solution."
    t ""

# game/script.rpy:262
translate english scene2_7f6efe66:

    # n "I vote nuclear!"
    n ""

# game/script.rpy:264
translate english scene2_41463c96:

    # t "It's much more complicated than just voting, but I love the spirit you've got there Nukey."
    t ""

# game/script.rpy:265
translate english scene2_527aba28:

    # t "Nuclear is an ideal combination of sustainability and reliability."
    t ""

# game/script.rpy:266
translate english scene2_89d0e3e1:

    # t "This concludes our geography lesson. Good work everyone!"
    t ""

# game/script.rpy:268
translate english scene2_bc8f858b:

    # "" "Now its time to decide, who did you agree with the most?"
    "" ""

# game/script.rpy:285
translate english agreewithnuclear_dd8fcd71:

    # t "Did you hear that Earth-chan?? The teacher said that nuclear is the best option for base power! How cool is that?"
    t ""

# game/script.rpy:286
translate english agreewithnuclear_736bac26:

    # e "I've never heard of it until now, but it sounds super cool!"
    e ""

# game/script.rpy:287
translate english agreewithnuclear_b11b0f1c:

    # e "All that clean power must be the way to the future."
    e ""

# game/script.rpy:288
translate english agreewithnuclear_b9305fe8:

    # t "EXACTLY! Ever since i began obsessing over reactors last wednesday, it's been all I can think about."
    t ""

# game/script.rpy:291
translate english agreewithnuclear_fd596dd0:

    # e "Last week?"
    e ""

# game/script.rpy:293
translate english agreewithnuclear_277e8dcc:

    # t "... Yeah?"
    t ""

# game/script.rpy:294
translate english agreewithnuclear_44dae180:

    # e "*To self* Shes mad."
    e ""

# game/script.rpy:295
translate english agreewithnuclear_96a03ee3:

    # e "*To self* But that's gotta be half the fun, right?"
    e ""

# game/script.rpy:296
translate english agreewithnuclear_e3d17c55:

    # t "TIME FOR PE!"
    t ""

# game/script.rpy:305
translate english agreewithsolar_429ed8a4:

    # e "Im kinda swayed to what you were saying."
    e ""

# game/script.rpy:308
translate english agreewithsolar_33b0fd3e:

    # e "A solar powered future sounds like good clean fun for everyone!"
    e ""

# game/script.rpy:312
translate english agreewithsolar_f947c9af:

    # s "But the teacher said that solar panels just aren't reliable enough."
    s ""

# game/script.rpy:313
translate english agreewithsolar_245b1033:

    # e "Surely that could be solved in the future?"
    e ""

# game/script.rpy:315
translate english agreewithsolar_0d198cde:

    # s "I don't know, Nukey. Perhaps it wasn't the right choice after all."
    s ""

# game/script.rpy:316
translate english agreewithsolar_f12292b2:

    # s "But all we can do now is keep moving forward. After all, it can still be used for peak energy production."
    s ""

# game/script.rpy:318
translate english agreewithsolar_c5be05f0:

    # e "You're right! It's not useless at all! Perhaps we will work best by combining nuclear AND renewables."
    e ""

# game/script.rpy:319
translate english agreewithsolar_e3d17c55:

    # t "TIME FOR PE!"
    t ""

# game/script.rpy:326
translate english agreewithcoal_2739d686:

    # c "You again? Seriously?"
    c ""

# game/script.rpy:327
translate english agreewithcoal_3c5f3a1c:

    # c "Are you being silly or something?"
    c ""

# game/script.rpy:331
translate english agreewithcoal_adec5c56:

    # c "The teacher made it clear that fossil fuels are not a good way of producing energy."
    c ""

# game/script.rpy:332
translate english agreewithcoal_a2352d64:

    # c "Go and bother someone else."
    c ""

# game/script.rpy:335
translate english agreewithcoal_d5cbf6c3:

    # e "Im just trying to talk to you about it! Surely it isn't a lost cause?"
    e ""

# game/script.rpy:338
translate english agreewithcoal_40749560:

    # e "Fossil fuels are so cheap, we can't blame people for using them at all!"
    e ""

# game/script.rpy:340
translate english agreewithcoal_8ee207c1:

    # c "Yeah, I suppose you're right. I didn't mean to get so angry."
    c ""

# game/script.rpy:341
translate english agreewithcoal_e897fbb0:

    # c "Thank you."
    c ""

# game/script.rpy:342
translate english agreewithcoal_e3d17c55:

    # t "TIME FOR PE!"
    t ""

# game/script.rpy:349
translate english scene3_802d64ef:

    # "" "*A storm clouds over the school*"
    "" ""

# game/script.rpy:350
translate english scene3_900f85b2:

    # t "It's about time we got our legs moving, everyone."
    t ""

# game/script.rpy:357
translate english scene3_0f3396e5:

    # "Everyone" "YAAAAAAAAAAY!!!"
    "Everyone" ""

# game/script.rpy:358
translate english scene3_b44e5b03:

    # t "With a cross country run!"
    t ""

# game/script.rpy:363
translate english scene3_3ecb48f4:

    # "Everyone" "aaaaaawwwwwwww..."
    "Everyone" ""

# game/script.rpy:364
translate english scene3_fdab4307:

    # s "I hate long activites, I can never keep up. It's just not who I am."
    s ""

# game/script.rpy:367
translate english scene3_7b85654e:

    # c "You just have to learn to pace yourselves, it isn't hard"
    c ""

# game/script.rpy:369
translate english scene3_70460274:

    # n "Im with Cole on this one, as long as you take your time you will run the same forever"
    n ""

# game/script.rpy:371
translate english scene3_93a3efc4:

    # e "Keeping a good pace sounds like a good way to go for this one"
    e ""

# game/script.rpy:375
translate english scene3_cc58fad2:

    # t "We will begin in 5..."
    t ""

# game/script.rpy:376
translate english scene3_926ee3a3:

    # t "4..."
    t ""

# game/script.rpy:377
translate english scene3_cd312fd1:

    # t "3..."
    t ""

# game/script.rpy:380
translate english scene3_13718244:

    # t "2..."
    t ""

# game/script.rpy:381
translate english scene3_29040070:

    # t "1..."
    t ""

# game/script.rpy:382
translate english scene3_c9a0f8d8:

    # t "GO!"
    t ""

# game/script.rpy:388
translate english scene3_2793aead:

    # n "She must learn to pace herself... Its like her energy levels change with the weather."
    n ""

# game/script.rpy:389
translate english scene3_fe480b04:

    # e "You're right. Sunny has got to stop pushing herself in bursts."
    e ""

# game/script.rpy:392
translate english scene3_a13b6b80:

    # e "What about Cole, though? He seemed quite confident."
    e ""

# game/script.rpy:395
translate english scene3_985cdde5:

    # n "Despite all his flaws, he can run for miles. His constant output is impressive to us all."
    n ""

# game/script.rpy:396
translate english scene3_0f8035aa:

    # n "Anyway, lets start running. This country wont cross itself!"
    n ""

# game/script.rpy:399
translate english scene3_c69bc610:

    # "" "Less that 10 minutes later"
    "" ""

# game/script.rpy:402
translate english scene3_5ad1557c:

    # s "*Gasp* *Gasp* AAaaahhhhh I can't do this any longer"
    s ""

# game/script.rpy:403
translate english scene3_d63236c5:

    # s "This is all too much..."
    s ""

# game/script.rpy:404
translate english scene3_93f1b26f:

    # s "Snoore..."
    s ""

# game/script.rpy:405
translate english scene3_93f1b26f_1:

    # s "Snoore..."
    s ""

# game/script.rpy:406
translate english scene3_93f1b26f_2:

    # s "Snoore..."
    s ""

# game/script.rpy:408
translate english scene3_ca16c444:

    # c "Whats wrong Sunny? A few clouds stopped your energy flowing? See ya!"
    c ""

# game/script.rpy:410
translate english scene3_93f1b26f_3:

    # s "Snoore..."
    s ""

# game/script.rpy:415
translate english scene3_aef92d5c:

    # e "Oh no! Sunny! Are you ok???"
    e ""

# game/script.rpy:416
translate english scene3_93f1b26f_4:

    # s "Snoore..."
    s ""

# game/script.rpy:417
translate english scene3_1e9ef712:

    # n "Oh, don't worry about her at all. When it gets cloudy or too active, she shuts right down to bed."
    n ""

# game/script.rpy:420
translate english scene3_51f6431c:

    # n "Best to just let sleeping dogs lie."
    n ""

# game/script.rpy:421
translate english scene3_ef1ed595:

    # e "Well, im sure you know best."
    e ""

# game/script.rpy:422
translate english scene3_2896e2e2:

    # "" "*The storm clears*"
    "" ""

# game/script.rpy:423
translate english scene3_322ad4d6:

    # n "Come on, lets get this run over with"
    n ""

# game/script.rpy:426
translate english scene3_413fc6d8:

    # "" "40 Minutes lates"
    "" ""

# game/script.rpy:427
translate english scene3_7fed57bd:

    # t "Good work everyone! The times are in. They are as follows:"
    t ""

# game/script.rpy:430
translate english scene3_bace0e7f:

    # t "Nukey: 23 Minutes"
    t ""

# game/script.rpy:433
translate english scene3_2ecb864e:

    # t "Cole: 28 Minutes"
    t ""

# game/script.rpy:437
translate english scene3_5a2fd2b4:

    # t "Earth-chan: 31 Minutes"
    t ""

# game/script.rpy:440
translate english scene3_eab476f2:

    # t "Sunny: DNF"
    t ""

# game/script.rpy:442
translate english scene3_e169bcdc:

    # t "Not good enough, Sunny!"
    t ""

# game/script.rpy:454
translate english scene3_b86b2703:

    # t "That concludes our PE lesson. We will have a quick break before we head to the art room. Enjoy!"
    t ""

# game/script.rpy:463
translate english scene4_83d2792d:

    # c "Now this is the perfect representation of our planet."
    c ""

# game/script.rpy:464
translate english scene4_c43ad091:

    # c "It is all just trash and pollution, there is no happiness in this."
    c ""

# game/script.rpy:467
translate english scene4_73d52f01:

    # n "You're just looking at it with a wrong view. Mine represents the reality the most."
    n ""

# game/script.rpy:468
translate english scene4_e7dc63df:

    # n "There are trees and greenery while also having the necessary factories helping the planet."
    n ""

# game/script.rpy:470
translate english scene4_d3ca9385:

    # c "No, mine is more accurate!"
    c ""

# game/script.rpy:471
translate english scene4_ae901d97:

    # n "Let's let earth-chan decide."
    n ""

# game/script.rpy:474
translate english scene4_4faf6bc4:

    # "" "You hear Sunny singing nearby"
    "" ""

# game/script.rpy:477
translate english scene4_f9f39cb6:

    # s "{i}Humming{/i}"
    s ""

# game/script.rpy:479
translate english scene4_11c3a048:

    # c "I see Sunny is drawing fantasy."
    c ""

# game/script.rpy:481
translate english scene4_2bdb02a9:

    # s "It is not fantasy. It's just how this planet really looks when we take care of it."
    s ""

# game/script.rpy:483
translate english scene4_721ab31f:

    # "" "Do you agree with Sunny?"
    "" ""

# game/script.rpy:506
translate english solarLandscape_e4b10185:

    # c "ugh, of course you would take her side."
    c ""

# game/script.rpy:509
translate english solarLandscape_491955c7:

    # n "I just, I just feel like something is missing."
    n ""

# game/script.rpy:510
translate english solarLandscape_e2a31e7d:

    # c "Yeah, reality."
    c ""

# game/script.rpy:515
translate english solarLandscape_1f14dec6:

    # e "Guys enough, Sunny is right, if we were to care about our planet it would be as beautiful as her painting."
    e ""

# game/script.rpy:518
translate english solarLandscape_401bb277:

    # c "I guess you're right Earth-chan, I'm sorry Sunny."
    c ""

# game/script.rpy:521
translate english solarLandscape_8fef258f:

    # s "It's okay Cole. I forgive you."
    s ""

# game/script.rpy:526
translate english solarLandscape_f5771849:

    # c "Oh please, what do you know?"
    c ""

# game/script.rpy:531
translate english solarLandscape_2637d10d:

    # s "Earth-chan, would you like to come with me later to clean the school grounds?"
    s ""

# game/script.rpy:534
translate english solarLandscape_e3d3f2ba:

    # e "Yes, of course! We will make this planet cleaner by filling one trash can at a time."
    e ""

# game/script.rpy:548
translate english coalLandscape_b1b99ac4:

    # s "Do you really think that there is no hope, Earth-chan?"
    s ""

# game/script.rpy:552
translate english coalLandscape_e2890b00:

    # e "Oh my god Solar, just stop with this fake happiness"
    e ""

# game/script.rpy:558
translate english coalLandscape_9e8d8ff8:

    # e "Sorry solar, I just don't think so."
    e ""

# game/script.rpy:572
translate english nuclearLandscape_f06fb9ad:

    # n "Of course they are! Without our nuclear power, how would we have what we do?"
    n ""

# game/script.rpy:573
translate english nuclearLandscape_7136f43d:

    # e "Without our nuclear power, how would we keep warm during winter?"
    e ""

# game/script.rpy:577
translate english nuclearLandscape_703a4ac3:

    # s "The sun would keep us warm..."
    s ""

# game/script.rpy:580
translate english nuclearLandscape_0223260d:

    # c "Sorry Sunny, not even I could agree with that."
    c ""

# game/script.rpy:581
translate english nuclearLandscape_c9406348:

    # e "Thanks to the industrial revolution we can achieve almost anything today! Including moving over oceans safely."
    e ""

# game/script.rpy:589
translate english scene5_7e210984:

    # t "Alright class, by using this formula we can see how electric cars benefit us."
    t ""

# game/script.rpy:590
translate english scene5_241b7436:

    # t "Would anyone like to say something about this topic?"
    t ""

# game/script.rpy:591
translate english scene5_906a3f3d:

    # t "Yes, Sunny?"
    t ""

# game/script.rpy:594
translate english scene5_d9d7c080:

    # s "I think that electric cars are great for our planet and will help it being more healthy in the future."
    s ""

# game/script.rpy:596
translate english scene5_03c95c17:

    # t "That is a great point Sunny! Would anybody else like to add to this? Coal"
    t ""

# game/script.rpy:598
translate english scene5_0e1720ee:

    # c "I think that that it doesn't matter. Planet will be here no matter what we do."
    c ""

# game/script.rpy:601
translate english scene5_60429b2f:

    # s "The planet might, but we for sure won't, and you better understand that!"
    s ""

# game/script.rpy:603
translate english scene5_a7d8cccf:

    # c "Oh, um, okay. Sorry."
    c ""

# game/script.rpy:607
translate english scene5_b6934e30:

    # e "Sunny leave Cole alone. He is only saying what he thinks is right."
    e ""

# game/script.rpy:610
translate english scene5_6aab6bab:

    # s "You never take my side Earth-chan. You have to know I am in the right now."
    s ""

# game/script.rpy:613
translate english scene5_6d59758e:

    # e "Because you're just always wrong Sunny!"
    e ""

# game/script.rpy:614
translate english scene5_c9120c4c:

    # e "Don't listen to her Cole. You're fine"
    e ""

# game/script.rpy:616
translate english scene5_d9e97708:

    # c "Thanks earth-chan"
    c ""

# game/script.rpy:622
translate english scene5_8a5dffb5:

    # s "{i}grunts.{/i} Fine."
    s ""

# game/script.rpy:627
translate english scene5_cf2fb99a:

    # n "I know nobody asked but it needs to be said. The electric cars are not good for us."
    n ""

# game/script.rpy:628
translate english scene5_08df6335:

    # n "They are nothing but a nuisance. They do not add to the nuclear power at all. Only the electric one."
    n ""

# game/script.rpy:630
translate english scene5_99f9c707:

    # t "Earth-chan would you like to add to this?"
    t ""

# game/script.rpy:652
translate english solarElectric_ffb1af3e:

    # s "See, Earth-chan agrees with me."
    s ""

# game/script.rpy:657
translate english solarElectric_d3d6cef7:

    # c "I guess you're right Sunny. It does matter."
    c ""

# game/script.rpy:661
translate english solarElectric_b1cf0b8f:

    # n "Of course you would say that when Earth-chan has agreed with her."
    n ""

# game/script.rpy:663
translate english solarElectric_6aa86201:

    # c "You're just jealous because we have so much in common."
    c ""

# game/script.rpy:666
translate english solarElectric_32ae8f1b:

    # c "You are all just overreacting."
    c ""

# game/script.rpy:669
translate english solarElectric_ea87579c:

    # n "You don't even know what we are talking about."
    n ""

# game/script.rpy:672
translate english solarElectric_b4ad9b29:

    # s "Yeah Cole, leave this conversation"
    s ""

# game/script.rpy:676
translate english solarElectric_6f61e2bd:

    # s "Electric cars are the future and that is final, Earth-chan agrees with me and thats it."
    s ""

# game/script.rpy:678
translate english solarElectric_d6c1052b:

    # n "Whatever..."
    n ""

# game/script.rpy:687
translate english coalElectric_9560bafc:

    # s "You did NOT just say that. Nuclear power is polluting the planet and we need to stop it."
    s ""

# game/script.rpy:692
translate english coalElectric_bf680e7d:

    # n "WRONG! Nuclear power is the reason where we are now. There is no future without it."
    n ""

# game/script.rpy:694
translate english coalElectric_be1fbee2:

    # s "Seriously, how could you even-"
    s ""

# game/script.rpy:698
translate english coalElectric_32c6da09:

    # "" "Sunny and Nukey argue nearby while Cole approaches you."
    "" ""

# game/script.rpy:700
translate english coalElectric_543a04a6:

    # c "Those two just never stop yapping about the health and efficiency of this planet, like it matters."
    c ""

# game/script.rpy:703
translate english coalElectric_02808bfa:

    # e "Yes, I agree it is a bit too much. Though I do take some of their points I do not think it's worth arguing over it."
    e ""

# game/script.rpy:713
translate english nuclearElectric_8e955048:

    # s "How could you even say that? Nuclear power is the reason our planet is struggling"
    s ""

# game/script.rpy:716
translate english nuclearElectric_043d673b:

    # n "Struggling at moving forward maybe."
    n ""

# game/script.rpy:718
translate english nuclearElectric_d424f4bf:

    # s "You both are just making me angry!"
    s ""

# game/script.rpy:720
translate english nuclearElectric_7183b840:

    # s "I just want the planet to be safe."
    s ""

# game/script.rpy:737
translate english solarCompassion_1bbbf5c1:

    # s "Thank you Earth-chan."
    s ""

# game/script.rpy:748
translate english solarHate_1841bc3d:

    # s "What is wrong with you? I hate you leave me alone!"
    s ""

# game/script.rpy:779
translate english nukesolEnding_23a9c204:

    # "" "Congratulations! This is without a doubt the most ideal of endings."
    "" ""

# game/script.rpy:780
translate english nukesolEnding_c741588d:

    # e "Thanks, both of you! It's been really fun."
    e ""

# game/script.rpy:781
translate english nukesolEnding_ad1cc6e7:

    # n "To work together with Sunny is brilliant!"
    n ""

# game/script.rpy:782
translate english nukesolEnding_83c3c798:

    # s "I provide all the energy we need for the peaks."
    s ""

# game/script.rpy:783
translate english nukesolEnding_ee62cd1c:

    # n "And im the strong baseline we need to get along as a minimum!"
    n ""

# game/script.rpy:784
translate english nukesolEnding_cde7f7b7:

    # e "Seeing you two together is a wonderful thing to see, and im sure it will bring us the best future we could possibly ask for."
    e ""

# game/script.rpy:787
translate english nukesolEnding_85949491:

    # "" "With the combined influences of nuclear and solar energies, Earth-chan grows up fit and healthy, living a long and prosperous life as a nuclear engineer for Rolls-Royce."
    "" ""

# game/script.rpy:796
translate english nukecoalEnding_97540848:

    # "" "A fair ending. You have combined the powers of nuclear and coal."
    "" ""

# game/script.rpy:797
translate english nukecoalEnding_c3c1fe6b:

    # e "Around you two, I feel like I have an endless amount of energy flowing through me!"
    e ""

# game/script.rpy:798
translate english nukecoalEnding_ffd89cfe:

    # n "With our combined high base power and reliability, we can fuel entire generations."
    n ""

# game/script.rpy:799
translate english nukecoalEnding_44dd8977:

    # c "Its a good day to be young."
    c ""

# game/script.rpy:800
translate english nukecoalEnding_82a51fe7:

    # e "It's still a tad dirty around here though..."
    e ""

# game/script.rpy:803
translate english nukecoalEnding_0309c3e8:

    # "" "A combination of both nuclear and coal provide Earth-chan with bountiful energy for the future. However, the looming pollution of fossil fuels continues to wreak havoc upon the environment."
    "" ""

# game/script.rpy:812
translate english solcoalEnding_cf74977a:

    # "" "An ok ending. You have combined the powers of solar and coal."
    "" ""

# game/script.rpy:813
translate english solcoalEnding_57db4e33:

    # e "Together we feel like a well balanced team, we got Cole giving us base power whilst Sunny peaks our energy when were feeling low."
    e ""

# game/script.rpy:814
translate english solcoalEnding_2c88cb64:

    # s "Were a great fitting team, though this fog does seem to block me out sometimes."
    s ""

# game/script.rpy:815
translate english solcoalEnding_93b6290c:

    # c "It's not perfect, but we can certainly get along. Besides, it's all just a few flowers. Who cares?"
    c ""

# game/script.rpy:818
translate english solcoalEnding_6339c0af:

    # "" "Together Cole and Sunny produce enough power to get by at base and peak load, but the pollution from fossil fuels begins to block the solar panels light. Its not an ideal way of life."
    "" ""

# game/script.rpy:826
translate english nuclearEnding_7ff186b5:

    # "" "This ending picks nuclear alone. Not terrible, but not great either."
    "" ""

# game/script.rpy:827
translate english nuclearEnding_27f603ff:

    # e "It's wonderful we can spend our time working together like this."
    e ""

# game/script.rpy:828
translate english nuclearEnding_73e6e053:

    # n "It's great and all, but sometimes I feel exhausted from providing so much energy alone."
    n ""

# game/script.rpy:829
translate english nuclearEnding_644edb84:

    # e "You're right. As clean as we are, sometimes life just gets all too much."
    e ""

# game/script.rpy:832
translate english nuclearEnding_9ee94615:

    # "" "With this ending, nuclear energy provides a clean source to many people, but under load it cannot reasonably increase output. Perhaps augmented with a renewable source we would be in a better place..."
    "" ""

# game/script.rpy:840
translate english solarEnding_29271434:

    # "" "This ending relies soley upon solar power."
    "" ""

# game/script.rpy:841
translate english solarEnding_aec8517a:

    # e "My lungs have never felt healthier. Look around us, nature is the cleanest it's been since -2000BC!"
    e ""

# game/script.rpy:842
translate english solarEnding_7112f33d:

    # e "But I sure do get drowsy often..."
    e ""

# game/script.rpy:843
translate english solarEnding_73ce5a52:

    # s "It is a beautiful view, you're right. But I just can't keep up with the demand for power!"
    s ""

# game/script.rpy:844
translate english solarEnding_aaacff60:

    # s "It rains sometimes too, you know!"
    s ""

# game/script.rpy:847
translate english solarEnding_ced7af39:

    # "" "This energy solution is not ideal. Solar energy can provide exceptional output, but come rain and storm and you will quickly lose power. Perhaps a base power source such as nuclear would be helpful..."
    "" ""

# game/script.rpy:854
translate english coalEnding_c95dec55:

    # "" "Probably the worst ending. Good job!"
    "" ""

# game/script.rpy:855
translate english coalEnding_f04de01c:

    # e "I have the power... but this endless pollution..."
    e ""

# game/script.rpy:856
translate english coalEnding_aea03e28:

    # e "Could this have been a cost too great?"
    e ""

# game/script.rpy:857
translate english coalEnding_eb94fe88:

    # c "Im sorry Earth-chan, but im not suited for your future."
    c ""

translate english strings:

    # game/script.rpy:112
    old "Sit with Nukey"
    new ""

    # game/script.rpy:112
    old "Sit with Sunny"
    new ""

    # game/script.rpy:112
    old "Sit with Cole"
    new ""

    # game/script.rpy:269
    old "Nukey and the Small Modular Reactors"
    new ""

    # game/script.rpy:269
    old "Sunny and the solar panels"
    new ""

    # game/script.rpy:269
    old "Cole and the fossil fuel route"
    new ""

    # game/script.rpy:445
    old "Amazing work, Nukey"
    new ""

    # game/script.rpy:445
    old "Your pace was impressive, Cole"
    new ""

    # game/script.rpy:445
    old "Don't worry Sunny, we can't all run 24/7"
    new ""

    # game/script.rpy:485
    old "That looks beautiful Sunny!"
    new ""

    # game/script.rpy:485
    old "I agree with coal, there is no happiness on this planet"
    new ""

    # game/script.rpy:485
    old "Nuclear is right! The factories are here because they are helpful."
    new ""

    # game/script.rpy:631
    old "I think that electric cars are good for our future. They please everyone in both movement and planets health."
    new ""

    # game/script.rpy:631
    old "It really does not matter. Both cars get to the destination."
    new ""

    # game/script.rpy:631
    old "Nuclear is right. This does NOT benefit nuclear power at all!"
    new ""

    # game/script.rpy:721
    old "Aww Sunny. I know you do. It is just our opinion."
    new ""

    # game/script.rpy:721
    old "Aww Sunny. It is ok to be wrong."
    new ""

    # game/script.rpy:721
    old "{i}Say nothing{/i}"
    new ""

