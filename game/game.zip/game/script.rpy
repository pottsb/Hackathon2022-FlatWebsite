﻿init python:
    def callback(event, **kwargs):
        if event == "show":
            renpy.music.play("audio/click4.mp3", channel="sound")
        elif event == "slow_done" or event == "end":
            renpy.music.stop(channel="sound")

define e = Character("Earth-chan", color="#3521eb", callback=callback)
define n = Character("Nukey", color="#6fe61f", callback=callback)
define s = Character("Sunny", color="#d6ec0f", callback=callback)
define c = Character("Cole", color="#ec300f", callback=callback)
define t = Character("Teacher", color="#464242", callback=callback)
default nuclearFriendship = 0
default solarFriendship = 0
default coalFriendship = -1
default topScore = 0



label start:

    scene bg scene1
    with fade

    t "Alright class!"
    t "Today we have a brand new member of our class."
    t "She doesn't know anyone from around here, so please be kind to her."
    t "She has asked to introduce herself, so here she is:"

    show earthchan neutral at center

    "???" "Hello everyone, im your new class member."
    e "Please, call me Earth-Chan."
    show earthchan excited:
        zoom(0.8)
    e "Im happy to meet you all today and hope we can all become great friends!"
    e "My favourite subject is geography, as I love to learn about this planet and how we effect it."
    show earthchan neutral:
        zoom(1.0)
    e "Thank you."

    "" "*The class is buzzing with excitement*"
    
    t "What a lovely introduction, im sure we will all get along great!"
    t "Would a few of you like to introduce yourselves as well?"
    "???" "I will!"

    show earthchan neutral at right with move
    pause(0.5)
    show nuclear excited at left with moveinleft:
    n "Its wonderful to meet you. Im Nuclear, but you can call me Nukey for short!"
    n "I love the world too, and hope to preserve it whilst helping the people that live in it. I want to become an engineer like my dad!."
    n "Also, your hair is -like- really cute."
    show earthchan excited:
        zoom(0.8)
    show nuclear neutral
    n "Lets become great friends!"
    show earthchan neutral:
        zoom(1.0)
    hide nuclear with moveoutleft
    "" "*Nukey sits back down.*"

    t "And who is next?"
    "???" "My turn! My turn! My turn!"

    show solar neutral at left with moveinleft

    s "My name is Sunny!"
    show solar excited
    s "My friends all say that I can be super hyper and friendly."
    show earthchan excited:
        zoom(0.8)
    show solar sad
    s "but I often find myself under the weather, and that really puts me down a notch."
    show earthchan neutral:
        zoom(1.0)
    show solar neutral
    s "Anyhow, its really cool to meet you."
    s "See ya!"
    hide solar with moveoutright

    t "Sunny, how many times must I tell you?"
    t "NO RUNNING IN THE CLASSRO- oh."
    t "They've already fallen asleep. Great."
    t "Would anyone else like to say hello to our new classmate?"
    "" "The class is silent"
    t "Cole! You're awfully quiet today. Why dont you say hello?"

    show coal neutral at left with moveinbottom
    c "Hi. Im Cole."
    c "..."
    c "I honestly think your loving the planet?"
    c "Is lame as hell."
    show earthchan angry:
        zoom(0.8)
    e "Why would you say that? It's so mean!"
    hide coal with moveoutbottom

    t "Cole! How dare you be so rude to our newest friend. Detention!"
    show earthchan sad at center with move:
        zoom(1.0)
    t "Don't worry about him. He is always like this to new people, and never behaves himself. If you run in to any problems, just tell me. Ok?"
    show earthchan neutral
    e "Ok... Thank you!"
    hide earthchan with moveoutbottom
    t "Now, who do you want to sit down with?"

    menu:
        "Sit with Nukey":
            $ nuclearFriendship+=1
            jump sitwithnuclear
        "Sit with Sunny":
            $ solarFriendship+=1
            jump sitwithsolar
        "Sit with Cole":
            $ coalFriendship+=1
            jump sitwithcoal

label sitwithnuclear:
    show earthchan neutral at right with moveinright
    show nuclear neutral at left with moveinleft
    pause(0.5)
    n "You want to sit with me? Thanks so much!"
    show nuclear excited
    n "I think were gonna get along really well."
    show nuclear neutral
    e "Yeah, im sure we can become best friends."
    show earthchan excited:
        zoom(0.8)
    e "What is it you love about engineering so much?"
    show nuclear excited
    n "My dad is a big inspiration, and works at a massive reactor thingy!"
    n "He says its the best compromise between clean energy and reliable output."
    show earthchan neutral:
        zoom(1.0)
    n "In not too sure what that means, but it sure sounds important!"
    t "OK CLASS! It's time for our first lesson. Geography!"
    jump scene2

label sitwithsolar:
    show earthchan neutral at right with moveinright
    show solar neutral at left with moveinleft 
    pause(0.5)
    s "Holy cow! Your gonna sit with me? Dope!"
    s "I know that together we can make this school year worth coming too"
    show solar excited
    s "SowhatdoyoudoinyoursparetimewhatsyournameagainhowoldareyouwhatschooldoyougotoholdonwegotothesameschoolwhydidIaskthatimjustsohappythatyoucametosayhellotomeandIhaveanewfriendbecausemostpeoplearekindofscaredbyhowmuchIcangetexcitedbylittlethingsandnewpeople"
    hide solar with moveoutbottom
    s "*Falls asleep*"
    show earthchan excited:
        zoom(0.8)
    e "*To self* That's going to happen a lot, isnt it?"
    t "OK CLASS! It's time for our first lesson. Geography!"
    jump scene2    

label sitwithcoal:
    show earthchan neutral at right with moveinright
    show coal sad at left with moveinleft
    pause(0.5)
    c "Seriously? Why did you even pick me?"
    show coal angry
    c "I don't want to talk to you. Go away."
    show earthchan excited:
        zoom(0.8)
    e "Im just curious as to why you hated what I had to say so much, im sure you're nice really!"
    show earthchan neutral
    c "Thanks, I guess."
    show coal sad
    c "It's just..."
    show coal excited
    c "Don't worry about it. I just dont like nature, thats all." #ayo lore: his parent were mauled during a safari trip
    c "As far as im concerned, all those plants can be burned to a cinder."
    e "Um... ok?"
    t "OK CLASS! It's time for our first lesson. Geography!"
    jump scene2

label scene2:
    scene bg scene2
    with fade
    t "Today we will be looking at a big, important topic. That is, climate change."
    t "More specifically, we will be looking at how we create energy for our homes, and what that can do to the world around us."
    t "Ok class, who can name a way we make power?"
    show nuclear excited at center with moveinbottom
    n "Nuclear reactors!"
    t "Thats correct! What could you tell us about those?"
    n "My dad works at one."
    show nuclear neutral
    n "um..."
    show nuclear sad
    "" "The class stares blankly."
    n "uh..." 
    show nuclear excited
    n "OH! I KNOW!"
    show nuclear neutral
    n "They are meant to be for base power, as they always give about the same amount of energy."
    n "It's super reliable!"
    n "That's all!"
    hide nuclear with moveoutbottom
    "" "Nukey sits back down"
    t "Thats right! A nuclear reactor is used to provide a continuous, reliable source of energy to the country."
    t "Its also pretty clean, with the waste products being only steam and spent fuel."
    t "Rolls-Royce's small modular reactor is exactly what we mean - "
    t "It will sustain our power generation whilst being more cheap than ever before."
    t "Thank you for that contribution , Nukey."
    t "Does anyone else have any ideas?"
    "" "..."
    "" "..."
    "" "..."
    show coal neutral at center with moveinleft
    c "What about coal?"
    c "You know, fossils and whatnot..."
    c "Dinosaur juice!"
    t "Exactly right, Cole!"
    t "Thank you for coming up and helping the class, its very good of you to help out"
    show coal angry
    c "Who even cares about the environment? It's just grass."
    hide coal with moveoutleft
    t "Those fossil fuels he mentioned are very cheap, but make the world a very dirty place"
    show earthchan neutral at right with moveinright
    show solar neutral at left with moveinleft
    "Earth-chan & Sunny" "A dirtier place??? Thats horrible!"
    t "Please sit down."
    "Earth-chan & Sunny" "Sorry Miss Teacher..."
    hide earth with moveoutright
    hide solar with moveoutright
    t "Anyway, as I was saying"
    t "There are many disadvantages to using fossil fuels, such as it harming the environment and warming us up."
    t "And yet we still use it every day."
    t "Its a funny old world, isnt it?"
    t "Ok, who else knows how we make our energy?"
    show solar neutral at center with moveinbottom
    s "I know one!"
    s "Solar panels! They are totally clean"
    show solar excited
    s "It absorbs power from the sun and lets us use it."
    s "How generous!"
    show solar sad
    s "But when it gets cloudy, I don't think it works so well"
    s "So im not sure if they are good at all."
    s "Sorry."
    hide solar with moveoutbottom
    t "No need to feel down about it, Sunny."
    t "Solar panels are a great, clean way to provide energy but it simply isn't reliable"
    t "How many cloudy days would it take for us to run out of power if we relied soley upon it?"
    t "They are worth using for now, but we could do with a more permenant solution."
    show nuclear excited at center with moveinbottom
    n "I vote nuclear!"
    hide nuclear with moveoutbottom
    t "It's much more complicated than just voting, but I love the spirit you've got there Nukey."
    t "Nuclear is an ideal combination of sustainability and reliability."
    t "This concludes our geography lesson. Good work everyone!"

    "" "Now its time to decide, who did you agree with the most?"
    menu:
        "Nukey and the Small Modular Reactors":
            $ nuclearFriendship+=1
            jump agreewithnuclear
        "Sunny and the solar panels":
            $ solarFriendship+=1
            jump agreewithsolar
        "Cole and the fossil fuel route":
            $ coalFriendship+=1
            jump agreewithcoal

label agreewithnuclear:
    show earthchan excited at right with moveinright:
        zoom(0.8)
    show nuclear excited at left with moveinleft
    t "Did you hear that Earth-chan?? The teacher said that nuclear is the best option for base power! How cool is that?"
    e "I've never heard of it until now, but it sounds super cool!"
    e "All that clean power must be the way to the future."
    t "EXACTLY! Ever since i began obsessing over reactors last wednesday, it's been all I can think about."
    show earthchan neutral
    e "Last week?"
    show nuclear neutral
    t "... Yeah?"
    e "*To self* Shes mad."
    e "*To self* But that's gotta be half the fun, right?"
    t "TIME FOR PE!"
    jump scene3


label agreewithsolar:
    show earthchan neutral at right with moveinright
    show solar excited at left with moveinleft
    e "Im kinda swayed to what you were saying."
    show earthchan excited:
        zoom(0.8)
    e "A solar powered future sounds like good clean fun for everyone!"
    show earthchan neutral
    show solar sad
    s "But the teacher said that solar panels just aren't reliable enough."
    e "Surely that could be solved in the future?"
    show solar neutral
    s "I don't know, Nukey. Perhaps it wasn't the right choice after all."
    s "But all we can do now is keep moving forward. After all, it can still be used for peak energy production."
    show solar excited
    e "You're right! It's not useless at all! Perhaps we will work best by combining nuclear AND renewables."
    t "TIME FOR PE!"
    jump scene3

label agreewithcoal:
    show earthchan neutral at right with moveinright
    show coal neutral at left with moveinleft
    c "You again? Seriously?"
    c "Are you being silly or something?"
    show earthchan sad:
        zoom(1.2)
    show coal angry
    c "The teacher made it clear that fossil fuels are not a good way of producing energy."
    c "Go and bother someone else."
    show earthchan angry:
        zoom(0.8)
    e "Im just trying to talk to you about it! Surely it isn't a lost cause?"
    show earthchan sad:
        zoom(1.2)
    e "Fossil fuels are so cheap, we can't blame people for using them at all!"
    show coal neutral
    c "Yeah, I suppose you're right. I didn't mean to get so angry."
    c "Thank you."
    t "TIME FOR PE!"
    jump scene3
    
label scene3:
    
    scene bg scene3
    with fade
    "" "*A storm clouds over the school*"
    t "It's about time we got our legs moving, everyone."
    show earthchan excited at center with moveinbottom:
        zoom(0.8)
    show nuclear excited at left with moveinbottom
    show solar excited at right with moveinbottom
    "Everyone" "YAAAAAAAAAAY!!!"
    t "With a cross country run!"
    show earthchan sad at center with moveinbottom:
        zoom(1.2)
    show nuclear sad at left with moveinbottom
    show solar sad at right with moveinbottom
    "Everyone" "aaaaaawwwwwwww..."
    s "I hate long activites, I can never keep up. It's just not who I am."
    hide solar with moveoutbottom
    show coal excited at right with moveinbottom
    c "You just have to learn to pace yourselves, it isn't hard"
    show nuclear excited
    n "Im with Cole on this one, as long as you take your time you will run the same forever"
    show nuclear neutral
    e "Keeping a good pace sounds like a good way to go for this one"
    hide coal with moveinbottom
    hide nuclear with moveinbottom
    hide earthchan with moveinbottom
    t "We will begin in 5..."
    t "4..."
    t "3..."
    show solar excited at right with moveinright
    t "2..."
    t "1..."
    t "GO!"
    hide solar with moveoutleft
    show earthchan neutral at right with moveinright:
        zoom(1.0)
    show nuclear neutral at center with moveinright
    n "She must learn to pace herself... Its like her energy levels change with the weather."
    e "You're right. Sunny has got to stop pushing herself in bursts."
    show earthchan sad:
        zoom(1.2)
    e "What about Cole, though? He seemed quite confident."
    show earthchan neutral:
        zoom(1.0)
    n "Despite all his flaws, he can run for miles. His constant output is impressive to us all."
    n "Anyway, lets start running. This country wont cross itself!"
    hide nuclear with moveoutleft
    hide earthchan with moveoutleft
    "" "Less that 10 minutes later"
    show solar neutral at center with moveintop
    s "*Gasp* *Gasp* AAaaahhhhh I can't do this any longer"
    s "This is all too much..."
    s "Snoore..."
    s "Snoore..."
    s "Snoore..."
    show coal excited at left with moveinright
    c "Whats wrong Sunny? A few clouds stopped your energy flowing? See ya!"
    hide coal with moveoutleft
    s "Snoore..."
    show nuclear neutral at left with moveinleft
    show earthchan sad at right with moveinleft
    e "Oh no! Sunny! Are you ok???"
    s "Snoore..."
    n "Oh, don't worry about her at all. When it gets cloudy or too active, she shuts right down to bed."
    show earthchan neutral
    n "Best to just let sleeping dogs lie."
    e "Well, im sure you know best."
    "" "*The storm clears*"
    n "Come on, lets get this run over with"
    hide nuclear with moveoutleft
    hide earthchan with moveoutleft
    "" "40 Minutes lates"
    t "Good work everyone! The times are in. They are as follows:"
    show nuclear excited
    t "Nukey: 23 Minutes"
    hide nuclear
    show coal excited
    t "Cole: 28 Minutes"
    hide coal
    show earthchan neutral
    t "Earth-chan: 31 Minutes"
    hide earthchan
    show solar sad
    t "Sunny: DNF"
    hide solar
    t "Not good enough, Sunny!"
    show earthchan neutral at center
    menu:
        "Amazing work, Nukey":
            $ nuclearFriendship+=1
            $ solarFriendship-=1
        "Your pace was impressive, Cole":
            $ coalFriendship+=1
            $ solarFriendship-=1
        "Don't worry Sunny, we can't all run 24/7":
            $ solarFriendship+=1
    t "That concludes our PE lesson. We will have a quick break before we head to the art room. Enjoy!"
    jump scene4

label scene4:

    scene bg scene4
    with fade

    show coal neutral at left with moveinleft
    c "Now this is the perfect representation of our planet."
    c "It is all just trash and pollution, there is no happiness in this."
    show nuclear neutral at right with moveinright
    n "You're just looking at it with a wrong view. Mine represents the reality the most."
    n "There are trees and greenery while also having the necessary factories helping the planet."
    show coal angry
    c "No, mine is more accurate!"
    n "Let's let earth-chan decide."
    hide coal with moveoutleft
    hide nuclear with moveoutbottom
    "" "You hear Sunny singing nearby"
    show solar excited at right with moveinright
    s "{i}Humming{/i}"
    show coal neutral at left with moveinleft
    c "I see Sunny is drawing fantasy."
    hide coal with moveoutleft
    s "It is not fantasy. It's just how this planet really looks when we take care of it."
    hide solar with moveoutright
    "" "Do you agree with Sunny?"

    menu:

        "That looks beautiful Sunny!":
            $ solarFriendship+=1
            jump solarLandscape

        "I agree with coal, there is no happiness on this planet":
            $ coalFriendship+=1
            jump coalLandscape

        "Nuclear is right! The factories are here because they are helpful.":
            $ nuclearFriendship+=1
            jump nuclearLandscape



label solarLandscape:
    show earthchan excited at center with moveinbottom:
        zoom(0.8)
    show coal angry at left with moveinleft
    c "ugh, of course you would take her side."
    show nuclear sad at right with moveinright
    n "I just, I just feel like something is missing."
    c "Yeah, reality."
    hide coal with moveoutleft
    hide nuclear with moveoutright
    show earthchan neutral:
        zoom(1.0)
    e "Guys enough, Sunny is right, if we were to care about our planet it would be as beautiful as her painting."
    show coal neutral at left with moveinleft
    if coalFriendship >= 1:
        c "I guess you're right Earth-chan, I'm sorry Sunny."
        show solar smiling at right with moveinright
        s "It's okay Cole. I forgive you."



    else:
        c "Oh please, what do you know?"

    hide coal with moveoutleft
    show solar excited at left with moveinleft
    s "Earth-chan, would you like to come with me later to clean the school grounds?"
    show earthchan excited at center with moveinbottom:
        zoom(0.8)
    e "Yes, of course! We will make this planet cleaner by filling one trash can at a time."
    hide solar with moveoutright
    hide coal with moveoutleft
    hide earthchan with moveoutbottom
    jump scene5



label coalLandscape:
    show earthchan sad at center with moveinbottom
    show coal excited at left with moveinleft
    show solar sad at right with moveinright
    s "Do you really think that there is no hope, Earth-chan?"
    if solarFriendship == 0:
        show earthchan angry:
            zoom(0.8)
        e "Oh my god Solar, just stop with this fake happiness"

    else:

        show earthchan neutral
        e "Sorry solar, I just don't think so."

    hide solar with moveoutright
    hide coal with moveoutleft
    hide earthchan with moveoutbottom
    jump scene5



label nuclearLandscape:
    show earthchan neutral at center with moveinbottom
    show nuclear excited at left with moveinleft
    n "Of course they are! Without our nuclear power, how would we have what we do?"
    e "Without our nuclear power, how would we keep warm during winter?"
    hide nuclear with moveoutleft
    show solar sad at right with moveinright
    s "The sun would keep us warm..."
    hide solar with moveoutright
    show coal neutral at right with moveinright
    c "Sorry Sunny, not even I could agree with that."
    e "Thanks to the industrial revolution we can achieve almost anything today! Including moving over oceans safely."
    jump scene5

label scene5:

    scene bg scene5
    with fade

    t "Alright class, by using this formula we can see how electric cars benefit us."
    t "Would anyone like to say something about this topic?"
    t "Yes, Sunny?"
    show solar excited at center with moveinbottom
    s "I think that electric cars are great for our planet and will help it being more healthy in the future."
    hide solar with moveoutbottom
    t "That is a great point Sunny! Would anybody else like to add to this? Coal"
    show coal neutral at left with moveinleft
    c "I think that that it doesn't matter. Planet will be here no matter what we do."
    show solar angry at right with moveinright
    s "The planet might, but we for sure won't, and you better understand that!"
    show coal angry at left with moveinleft
    c "Oh, um, okay. Sorry."
    hide coal with moveoutleft
    if coalFriendship >= 1:
        show earthchan at left with moveinleft
        e "Sunny leave Cole alone. He is only saying what he thinks is right."
        if solarFriendship <= 0:
            show solar angry at right with moveinright
            s "You never take my side Earth-chan. You have to know I am in the right now."
            show earthchan angry at left with moveinleft
            e "Because you're just always wrong Sunny!"
            e "Don't listen to her Cole. You're fine"
            show coal at center with moveinbottom
            c "Thanks earth-chan"
            hide coal with moveoutbottom
            hide solar with moveoutright
            hide earthchan with moveoutleft
        else:
            show solar sad at right with moveinright
            s "{i}grunts.{/i} Fine."
            $ solarFriendship -= 1
            hide solar with moveoutright
    show nuclear neutral at left with moveinleft
    n "I know nobody asked but it needs to be said. The electric cars are not good for us."
    n "They are nothing but a nuisance. They do not add to the nuclear power at all. Only the electric one."
    hide nuclear with moveoutleft
    t "Earth-chan would you like to add to this?"
    menu:
        "I think that electric cars are good for our future. They please everyone in both movement and planets health.":
            $ solarFriendship+=1
            $ nuclearFriendship -= 1
            jump solarElectric
        "It really does not matter. Both cars get to the destination.":
            $ coalFriendship+=2
            $ nuclearFriendship -= 1
            $ solarFriendship -= 1
            jump coalElectric
        "Nuclear is right. This does NOT benefit nuclear power at all!":
            $ nuclearFriendship+=1
            $ solarFriendship -= 1
            jump nuclearElectric

label solarElectric:

    show earthchan neutral at right with moveinright
    show solar neutral at left with moveinleft
    s "See, Earth-chan agrees with me."
    hide earthchan with moveoutright
    hide solar with moveoutleft
    if coalFriendship >= 1:
        show coal excited at center with moveinbottom
        c "I guess you're right Sunny. It does matter."
        hide coal with moveoutbottom
        show nuclear neutral at right with moveinright
        n "Of course you would say that when Earth-chan has agreed with her."
        show coal at left with moveinleft
        c "You're just jealous because we have so much in common."
    else:
        show coal neutral at left with moveinleft
        c "You are all just overreacting."
        show nuclear angry at right with moveinright
        n "You don't even know what we are talking about."
        show solar angry at center with moveinbottom
        s "Yeah Cole, leave this conversation"
        show coal sad at left with moveinleft
        hide coal with moveoutleft
        show solar neutral at left with moveinleft
        s "Electric cars are the future and that is final, Earth-chan agrees with me and thats it."
        show nuclear sad at right with moveinright
        n "Whatever..."

label coalElectric:

    show earthchan neutral at center with moveinbottom
    show coal excited at left with moveinleft
    show solar angry at right with moveinright
    s "You did NOT just say that. Nuclear power is polluting the planet and we need to stop it."
    hide coal with moveoutleft
    show earthchan at left with moveinleft
    show nuclear neutral at center with moveinbottom
    n "WRONG! Nuclear power is the reason where we are now. There is no future without it."
    show solar neutral at right with moveinright
    s "Seriously, how could you even-"
    hide nuclear with moveoutbottom
    hide solar with moveoutright
    hide earthchan with moveoutleft
    "" "Sunny and Nukey argue nearby while Cole approaches you."
    show coal angry at right with moveinright
    c "Those two just never stop yapping about the health and efficiency of this planet, like it matters."
    show earthchan angry at left with moveinleft
    e "Yes, I agree it is a bit too much. Though I do take some of their points I do not think it's worth arguing over it."
    hide coal with moveoutright
    hide earthchan with moveoutleft

label nuclearElectric:

    show earthchan angry at left with moveinleft
    show solar angry at right with moveinright
    s "How could you even say that? Nuclear power is the reason our planet is struggling"
    show nuclear neutral at center with moveinbottom
    n "Struggling at moving forward maybe."
    show solar angry at right with moveinright
    s "You both are just making me angry!"
    show solar sad at right with moveinright
    s "I just want the planet to be safe."
    menu:
        "Aww Sunny. I know you do. It is just our opinion.":
            $ solarFriendship+=1
            jump solarCompassion
        "Aww Sunny. It is ok to be wrong.":
            $ solarFriendship -= 3
            jump solarHate
        "{i}Say nothing{/i}":
            jump scene6

label solarCompassion:
    hide nuclear with moveoutbottom
    show earthchan neutral at left with moveinleft
    show solar excited at right with moveinright
    s "Thank you Earth-chan."
    hide earthchan with moveoutleft
    hide solar with moveoutright
    jump scene6

label solarHate:
    hide nuclear with moveoutbottom
    show earthchan angry at left with moveinleft
    show solar angry at right with moveinright
    s "What is wrong with you? I hate you leave me alone!"
    hide earthchan with moveoutleft
    hide solar with moveoutright
    jump scene6

label scene6:
    hide nuclear
    hide solar
    hide coal
    hide earthchan
    $ topScore = max(nuclearFriendship, solarFriendship, coalFriendship)
    if nuclearFriendship == solarFriendship:
        jump nukesolEnding
    elif nuclearFriendship == coalFriendship:
        jump nukecoalEnding
    elif solarFriendship == coalFriendship:
        jump solcoalEnding
    elif topScore == nuclearFriendship:
        jump nuclearEnding
    elif topScore == solarFriendship:
        jump solarEnding
    else:
        jump coalEnding

label nukesolEnding:
    show earthchan excited at center with moveoutleft
    show nuclear excited at left with moveoutright
    show solar excited at right with moveoutright
    "" "Congratulations! This is without a doubt the most ideal of endings."
    e "Thanks, both of you! It's been really fun."
    n "To work together with Sunny is brilliant!"
    s "I provide all the energy we need for the peaks."
    n "And im the strong baseline we need to get along as a minimum!"
    e "Seeing you two together is a wonderful thing to see, and im sure it will bring us the best future we could possibly ask for."
    hide nuclear
    hide solar
    "" "With the combined influences of nuclear and solar energies, Earth-chan grows up fit and healthy, living a long and prosperous life as a nuclear engineer for Rolls-Royce."
    jump end

label nukecoalEnding:
    show earthchan excited at center with moveoutleft
    show nuclear excited at left with moveoutright
    show coal excited at right with moveoutright
    "" "A fair ending. You have combined the powers of nuclear and coal."
    e "Around you two, I feel like I have an endless amount of energy flowing through me!"
    n "With our combined high base power and reliability, we can fuel entire generations."
    c "Its a good day to be young."
    e "It's still a tad dirty around here though..."
    hide nuclear
    hide coal
    "" "A combination of both nuclear and coal provide Earth-chan with bountiful energy for the future. However, the looming pollution of fossil fuels continues to wreak havoc upon the environment."
    jump end

label solcoalEnding:
    show earthchan excited at center with moveoutleft
    show solar excited at left with moveoutright
    show coal excited at right with moveoutright
    "" "An ok ending. You have combined the powers of solar and coal."
    e "Together we feel like a well balanced team, we got Cole giving us base power whilst Sunny peaks our energy when were feeling low."
    s "Were a great fitting team, though this fog does seem to block me out sometimes."
    c "It's not perfect, but we can certainly get along. Besides, it's all just a few flowers. Who cares?"
    hide solar
    hide coal
    "" "Together Cole and Sunny produce enough power to get by at base and peak load, but the pollution from fossil fuels begins to block the solar panels light. Its not an ideal way of life."
    jump end

label nuclearEnding:
    show earthchan excited at left with moveoutleft
    show nuclear excited at right with moveoutright
    "" "This ending picks nuclear alone. Not terrible, but not great either."
    e "It's wonderful we can spend our time working together like this."
    n "It's great and all, but sometimes I feel exhausted from providing so much energy alone."
    e "You're right. As clean as we are, sometimes life just gets all too much."
    hide nuclear
    show earthchan at center with moveinleft
    "" "With this ending, nuclear energy provides a clean source to many people, but under load it cannot reasonably increase output. Perhaps augmented with a renewable source we would be in a better place..."
    jump end

label solarEnding:
    show earthchan excited at left with moveoutleft
    show solar excited at right with moveoutright
    "" "This ending relies soley upon solar power."
    e "My lungs have never felt healthier. Look around us, nature is the cleanest it's been since -2000BC!"
    e "But I sure do get drowsy often..."
    s "It is a beautiful view, you're right. But I just can't keep up with the demand for power!"
    s "It rains sometimes too, you know!"
    hide solar
    show earthchan at center with moveinleft
    "" "This energy solution is not ideal. Solar energy can provide exceptional output, but come rain and storm and you will quickly lose power. Perhaps a base power source such as nuclear would be helpful..."
    jump end

label coalEnding:
    show earthchan excited at left with moveoutleft
    show coal sad at right with moveoutright
    "" "Probably the worst ending. Good job!"
    e "I have the power... but this endless pollution..."
    e "Could this have been a cost too great?"
    c "Im sorry Earth-chan, but im not suited for your future."
    jump end

label end:
    scene bg end
    pause